package com.deka.correcao;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CorrecaoApplicationTests {

	@Test
	void contextLoads() {
	}

}
